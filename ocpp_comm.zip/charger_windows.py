"""
OCPP 충전소 시뮬레이터 GUI - 충전기 관련 창
"""

import tkinter as tk
from tkinter import ttk, messagebox
import asyncio
import random

class LoginWindow(tk.Toplevel):
    """로그인 창"""
    
    def __init__(self, parent, charger_id, on_login_success):
        super().__init__(parent)
        self.title(f"충전기 {charger_id} 로그인")
        self.geometry("300x200")
        self.resizable(False, False)
        self.charger_id = charger_id
        self.on_login_success = on_login_success
        
        # Center window
        self.update_idletasks()
        width = self.winfo_width()
        height = self.winfo_height()
        x = (self.winfo_screenwidth() // 2) - (width // 2)
        y = (self.winfo_screenheight() // 2) - (height // 2)
        self.geometry(f'+{x}+{y}')
        
        # Create widgets
        self.create_widgets()
        
    def create_widgets(self):
        """위젯 생성"""
        # Main frame
        main_frame = ttk.Frame(self, padding="20")
        main_frame.pack(fill=tk.BOTH, expand=True)
        
        # Title
        title_label = ttk.Label(main_frame, text=f"충전기 {self.charger_id} 로그인", font=("Arial", 14, "bold"))
        title_label.pack(pady=(0, 20))
        
        # Username
        username_frame = ttk.Frame(main_frame)
        username_frame.pack(fill=tk.X, pady=5)
        
        username_label = ttk.Label(username_frame, text="아이디:", width=10)
        username_label.pack(side=tk.LEFT)
        
        self.username_entry = ttk.Entry(username_frame)
        self.username_entry.pack(side=tk.LEFT, fill=tk.X, expand=True)
        
        # Password
        password_frame = ttk.Frame(main_frame)
        password_frame.pack(fill=tk.X, pady=5)
        
        password_label = ttk.Label(password_frame, text="비밀번호:", width=10)
        password_label.pack(side=tk.LEFT)
        
        self.password_entry = ttk.Entry(password_frame, show="*")
        self.password_entry.pack(side=tk.LEFT, fill=tk.X, expand=True)
        
        # Login button
        style = ttk.Style()
        style.configure("Login.TButton", font=("Arial", 11, "bold"))
        login_button = ttk.Button(main_frame, text="로그인", command=self.login, style="Login.TButton")
        login_button.pack(pady=20, ipadx=10, ipady=5)
        
    def login(self):
        """로그인 처리"""
        # For this demo, any username/password is accepted
        username = self.username_entry.get()
        password = self.password_entry.get()
        
        if username and password:
            self.destroy()
            self.on_login_success()
        else:
            messagebox.showerror("로그인 오류", "아이디와 비밀번호를 모두 입력해주세요")

class ChargingWindow(tk.Toplevel):
    """충전 제어 창"""
    
    def __init__(self, parent, charger_id, ocpp_client, event_loop):
        super().__init__(parent)
        self.title(f"충전기 {charger_id}")
        self.geometry("400x350")  # Increased height to accommodate buttons
        self.resizable(False, False)
        self.charger_id = charger_id
        self.ocpp_client = ocpp_client
        self.event_loop = event_loop
        self.charging = False
        self.use_serial = ocpp_client.use_serial
        self.power_update_timer = None
        
        # Center window
        self.update_idletasks()
        width = self.winfo_width()
        height = self.winfo_height()
        x = (self.winfo_screenwidth() // 2) - (width // 2) + (self.charger_id - 1) * 50
        y = (self.winfo_screenheight() // 2) - (height // 2) + (self.charger_id - 1) * 50
        self.geometry(f'+{x}+{y}')
        
        # Create widgets
        self.create_widgets()
        
        # Protocol for closing
        self.protocol("WM_DELETE_WINDOW", self.on_closing)
        
    def create_widgets(self):
        """위젯 생성"""
        # Main frame
        main_frame = ttk.Frame(self, padding="20")
        main_frame.pack(fill=tk.BOTH, expand=True)
        
        # Title
        title_label = ttk.Label(main_frame, text=f"충전기 {self.charger_id}", font=("Arial", 16, "bold"))
        title_label.pack(pady=(0, 20))
        
        # Status
        self.status_var = tk.StringVar(value="준비됨")
        status_frame = ttk.Frame(main_frame)
        status_frame.pack(fill=tk.X, pady=10)
        
        status_label = ttk.Label(status_frame, text="상태:", width=10)
        status_label.pack(side=tk.LEFT)
        
        status_value = ttk.Label(status_frame, textvariable=self.status_var, font=("Arial", 10, "bold"))
        status_value.pack(side=tk.LEFT)
        
        # Price input with start button
        price_frame = ttk.Frame(main_frame)
        price_frame.pack(fill=tk.X, pady=10)
        
        price_label = ttk.Label(price_frame, text="가격 (₩):", width=10)
        price_label.pack(side=tk.LEFT)
        
        self.price_entry = ttk.Entry(price_frame)
        self.price_entry.pack(side=tk.LEFT, fill=tk.X, expand=True)
        self.price_entry.insert(0, "500")  # Default price
        
        # Power display (not editable if serial is connected)
        power_frame = ttk.Frame(main_frame)
        power_frame.pack(fill=tk.X, pady=10)
        
        power_label = ttk.Label(power_frame, text="전력 (W):", width=10)
        power_label.pack(side=tk.LEFT)
        
        if self.use_serial:
            # If serial is connected, show a label instead of entry
            self.power_var = tk.StringVar(value="0")
            power_display = ttk.Label(power_frame, textvariable=self.power_var)
            power_display.pack(side=tk.LEFT, fill=tk.X, expand=True)
            
            # Add a note about serial connection
            serial_note = ttk.Label(main_frame, text="* 시리얼 연결: 전력값은 아두이노에서 수신됩니다", 
                                   font=("Arial", 8), foreground="blue")
            serial_note.pack(fill=tk.X, pady=(0, 10))
        else:
            # If no serial, allow manual power input
            self.power_entry = ttk.Entry(power_frame)
            self.power_entry.pack(side=tk.LEFT, fill=tk.X, expand=True)
            self.power_entry.insert(0, "3000")  # Default power
            
            # Add a note about manual mode
            manual_note = ttk.Label(main_frame, text="* 수동 모드: 전력값을 직접 입력하세요", 
                                   font=("Arial", 8), foreground="orange")
            manual_note.pack(fill=tk.X, pady=(0, 10))
        
        # Current power display
        current_power_frame = ttk.Frame(main_frame)
        current_power_frame.pack(fill=tk.X, pady=10)
        
        current_power_label = ttk.Label(current_power_frame, text="현재 전력:", width=10)
        current_power_label.pack(side=tk.LEFT)
        
        self.current_power_var = tk.StringVar(value="0 W")
        current_power_value = ttk.Label(current_power_frame, textvariable=self.current_power_var)
        current_power_value.pack(side=tk.LEFT)
        
        # Create a separate frame for buttons at the bottom
        bottom_frame = ttk.Frame(self)
        bottom_frame.pack(side=tk.BOTTOM, fill=tk.X, padx=20, pady=20)
        
        # Create the start button with explicit styling
        self.start_button = tk.Button(
            bottom_frame, 
            text="충전 시작", 
            command=self.start_charging,
            bg="#4CAF50",  # Green background
            fg="white",    # White text
            font=("Arial", 12, "bold"),
            height=2,
            relief=tk.RAISED,
            borderwidth=3
        )
        self.start_button.pack(side=tk.LEFT, expand=True, fill=tk.X, padx=(0, 5))
        
        # Create the stop button with explicit styling
        self.stop_button = tk.Button(
            bottom_frame, 
            text="충전 중지", 
            command=self.stop_charging,
            bg="#F44336",  # Red background
            fg="white",    # White text
            font=("Arial", 12, "bold"),
            height=2,
            state=tk.DISABLED,
            relief=tk.RAISED,
            borderwidth=3
        )
        self.stop_button.pack(side=tk.RIGHT, expand=True, fill=tk.X, padx=(5, 0))
        
    def update_power_display(self, power_value):
        """전력 표시 업데이트"""
        self.current_power_var.set(f"{power_value} W")
        if self.use_serial and hasattr(self, 'power_var'):
            self.power_var.set(str(power_value))
        
    def update_status(self, status):
        """상태 업데이트"""
        self.status_var.set(status)
        
    def start_charging(self):
        """충전 시작"""
        try:
            price = float(self.price_entry.get())
            
            if price <= 0:
                messagebox.showerror("입력 오류", "가격은 양수여야 합니다")
                return
            
            # Get power value based on connection type
            if self.use_serial:
                # For serial connection, use a default power to start
                # The actual power will come from Arduino
                power = 3000  # Default starting power
            else:
                # For manual mode, get power from entry
                power = float(self.power_entry.get())
                if power <= 0:
                    messagebox.showerror("입력 오류", "전력은 양수여야 합니다")
                    return
            
            # Run in the event loop
            asyncio.run_coroutine_threadsafe(
                self.ocpp_client.start_charging(self.charger_id, power), 
                self.event_loop
            )
            
            self.charging = True
            self.status_var.set("충전 중")
            self.start_button.config(state=tk.DISABLED)
            self.stop_button.config(state=tk.NORMAL)
            self.price_entry.config(state=tk.DISABLED)
            
            if not self.use_serial and hasattr(self, 'power_entry'):
                self.power_entry.config(state=tk.DISABLED)
                
            # If no serial connection, simulate power changes
            if not self.use_serial:
                self.simulate_power_changes()
                
        except ValueError:
            messagebox.showerror("입력 오류", "가격과 전력에 유효한 숫자를 입력하세요")
    
    def simulate_power_changes(self):
        """시리얼 연결이 없을 때 전력 변화 시뮬레이션"""
        if not self.charging:
            return
            
        # Get base power from entry
        if hasattr(self, 'power_entry'):
            base_power = float(self.power_entry.get())
        else:
            base_power = 3000
            
        # Add some random variation
        variation = random.uniform(-200, 200)
        new_power = max(0, base_power + variation)
        
        # Update the client's power data
        self.ocpp_client.manual_power[self.charger_id - 1] = new_power
        
        # Schedule next update
        self.power_update_timer = self.after(2000, self.simulate_power_changes)
    
    def stop_charging(self):
        """충전 중지"""
        # Run in the event loop
        asyncio.run_coroutine_threadsafe(
            self.ocpp_client.stop_charging(self.charger_id), 
            self.event_loop
        )
        
        self.charging = False
        self.status_var.set("준비됨")
        self.start_button.config(state=tk.NORMAL)
        self.stop_button.config(state=tk.DISABLED)
        self.price_entry.config(state=tk.NORMAL)
        
        if not self.use_serial and hasattr(self, 'power_entry'):
            self.power_entry.config(state=tk.NORMAL)
            
        # Cancel power simulation if active
        if self.power_update_timer:
            self.after_cancel(self.power_update_timer)
            self.power_update_timer = None
            
    def on_closing(self):
        """창 닫기 처리"""
        if self.charging:
            if messagebox.askyesno("충전 중지", "충전이 진행 중입니다. 중지하고 창을 닫으시겠습니까?"):
                self.stop_charging()
                self.destroy()
        else:
            self.destroy()
